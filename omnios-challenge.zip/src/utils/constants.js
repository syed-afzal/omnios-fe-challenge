export const LOGIN = '/login';
export const SIGN_UP = '/sign-up';
export const APP = '/';
